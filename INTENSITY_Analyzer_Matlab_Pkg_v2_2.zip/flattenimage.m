function [Yc,Yf]=flattenimage(img,imc) 
% -----------------------------------------------------------
% TK Kozai March 30 2015
% flatten an image intensity and increase signal in the edges
%[Yc,Yf]=flattenimage(img,imc)
% img = image to be corrected
% optional 
%   imc = control image to generate mask for flattening
% Yc = corrected image
% Yf = mask used to correct image
vdim = size(img);
imdim = max(vdim);
dim2=imdim/2;

thres = 5;
thres = thres * 0.01;

Y=img;
Yc=zeros(size(img));
Yf=zeros(size(img));

if nargin==1
    imc=img;
end

    imc=squeeze(Y(:,:,1));
    imax = max(max(imc));
    imin = min(min(imc));
    imgResh = reshape(imc,[prod(size(imc)),1]);
    imed = median(imgResh);
    imean = mean(imgResh);
    istd = std(double(imgResh));
    ithr = imax*thres;
    ithr2 = imean + 2.5*istd;
    
    mask = (ones(size(imc)));
    imask = double(imc).*mask;
    iave = sum(sum(imask))/sum(sum(mask));
    imc=double(imc);
    imc(find(imc>=ithr2)) = sum(sum(imc.*(imc<ithr2)))/sum(sum(mask));
    mask = (imc>ithr);
    ifill = imask + (1-mask).*iave;
    z = fftshift(fft2(ifill));
    ndef = dim2/8;		
    n = ndef;
    yt = (1:dim2).^2;  
    a = 1/n;
    for x=1:dim2
      r = yt +x*x;
      wintemp(x,:) = exp(-a*r);
    end
    win(dim2+1:imdim,dim2+1:imdim) = wintemp;
    win(dim2+1:imdim,dim2:-1:1) = wintemp;
    win(1:dim2,:) = win(imdim:-1:dim2+1,:);
    z2 = win.*z;
    ilow = abs(ifft2(fftshift(z2)));
    ilave = sum(sum(ilow.*mask))/sum(sum(mask));
    ifilt = (ilave./ilow).*mask;  % correction factor
    img=double(img);
    icor = img.*ifilt;
    
    if min(min(icor))>0
        icor=icor-min(min(icor));
    elseif min(min(icor))<0
        icor(icor<0)=0;
    end
    icor=uint16(round(icor));
   
    Yc = icor;
    Yf = ifilt;
end