%%%Save Output Values in Excel%%%

name=[pre,filenamei,'_chan',num2str(chan_loop),'.xls'];
var={'Bin lower (um)','Bin upper (um)','SNIR','Area um^2','Bckgrnd Threshold','Avg Bckgrnd Int','Bckgrnd STD' ...
    '#Subthresh pxl','Signal Threshold','%Threshold'};    

%Row 1: Variable names  
xlswrite(name,var,1,'A1');
%Lower Bin
xlswrite(name,d1_bin',1,'A2');
%Upper Bin
xlswrite(name,d2_bin',1,'B2');
%Mean Bin Intensity
xlswrite(name,bin_int',1,'C2');
%Mean Bin Area
xlswrite(name,bin_area',1,'D2');
%Threshold for Noise Calculation
xlswrite(name,thresh,1,'E2');
%Average Background Intensity
xlswrite(name,avgbk,1,'F2');
%Standard Deviation of Background Intensity
xlswrite(name,stdbk,1,'G2');
%Number of Pixels below Threshold (used for Noise calculation)
xlswrite(name,stn0,1,'H2');
%Signal Threshold for Exerpimental image 
xlswrite(name,avgbkn,1,'I2');
%Percent of Pixels below Signal Threshold
xlswrite(name,stn,1,'J2');
