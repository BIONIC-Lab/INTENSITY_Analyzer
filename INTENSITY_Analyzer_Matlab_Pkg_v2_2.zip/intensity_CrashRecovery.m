    immuno=input('Stain/Label Name?: ', 's');
    iDataf=strcat(immuno, '_Data');
    xlswrite(iDataf, istoreA);